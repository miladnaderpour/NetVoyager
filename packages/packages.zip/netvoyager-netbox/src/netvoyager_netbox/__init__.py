"""NetVoyager netbox domain package."""
