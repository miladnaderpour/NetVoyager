"""Models for parsed Palo Alto BGP local RIB output."""

from dataclasses import dataclass
from ipaddress import IPv4Address, IPv4Network
from typing import Literal


@dataclass(frozen=True, slots=True)
class BgpRoute:
    prefix: IPv4Network
    next_hop: IPv4Address | None
    peer: str
    as_path: tuple[int, ...]
    marker: Literal["*"] | None  # empty tuple when the column is blank
    line_number: int
    raw_line: str


@dataclass(frozen=True, slots=True)
class UnparsedLine:
    line_number: int
    reason: str
    raw_line: str


@dataclass(frozen=True, slots=True)
class BgpRibResult:
    virtual_router: str
    virtual_router_id: int | None
    routes: tuple[BgpRoute, ...]
    total_routes_shown: int | None
    unparsed_lines: tuple[UnparsedLine, ...]


@dataclass(frozen=True, slots=True)
class BgpRibDump:
    routers: tuple[BgpRibResult, ...]
    unparsed_lines: tuple[UnparsedLine, ...] = ()