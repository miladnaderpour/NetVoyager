"""NetVoyager discovery domain package."""
